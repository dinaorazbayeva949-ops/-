"""
Поиск юбиляров и автоматическая отправка поздравлений по email.

Каждый запуск (обычно — раз в день из GitHub Actions) скрипт:
  1. Читает файл со списком сотрудников (по умолчанию data/employees.xlsx).
  2. Находит тех, у кого сегодня (или через REMINDER_DAYS_BEFORE дней) юбилей —
     возраст, кратный MILESTONE_STEP, начиная с MILESTONE_START лет.
  3. Формирует персональное поздравление (пол определяется по окончанию ФИО).
  4. Отправляет письмо через SMTP.
  5. Записывает отправленные поздравления в data/sent_log.csv, чтобы не отправить дважды.

Все параметры настраиваются через переменные окружения (см. .env.example).
"""

import csv
import os
import smtplib
import ssl
import sys
from datetime import date, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import pandas as pd

# ---------- Конфигурация ----------
DATA_FILE = Path(os.getenv("DATA_FILE", "data/employees.xlsx"))
SENT_LOG_FILE = Path(os.getenv("SENT_LOG_FILE", "data/sent_log.csv"))

MILESTONE_START = int(os.getenv("MILESTONE_START", "50"))
MILESTONE_STEP = int(os.getenv("MILESTONE_STEP", "5"))
REMINDER_DAYS_BEFORE = int(os.getenv("REMINDER_DAYS_BEFORE", "0"))  # 0 = в сам день

SMTP_SERVER = os.getenv("SMTP_SERVER")
SMTP_PORT = int(os.getenv("SMTP_PORT", "465"))
SMTP_USERNAME = os.getenv("SMTP_USERNAME")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
SENDER_NAME = os.getenv("SENDER_NAME", "Коллектив компании")

REQUIRED_COLUMNS = ["ФИО", "Дата рождения", "Email"]

MALE_ENDINGS = ("ович", "евич", "улы", "ұлы")
FEMALE_ENDINGS = ("овна", "евна", "кызы", "қызы")


def detect_greeting(full_name: str) -> str:
    name = full_name.strip().lower()
    if name.endswith(FEMALE_ENDINGS):
        return "Уважаемая"
    if name.endswith(MALE_ENDINGS):
        return "Уважаемый"
    return "Уважаемый(ая)"


def build_message(full_name: str, age: int) -> str:
    greeting = detect_greeting(full_name)
    return (
        f"{greeting} {full_name.title()}!\n\n"
        f"От всей души поздравляем Вас с юбилеем — {age}-летием со дня рождения!\n"
        f"Желаем крепкого здоровья, благополучия, успехов в работе и всего самого "
        f"доброго Вам и Вашим близким.\n\n"
        f"С уважением, {SENDER_NAME}."
    )


def load_employees() -> pd.DataFrame:
    if not DATA_FILE.exists():
        sys.exit(f"Файл с данными не найден: {DATA_FILE}")
    df = pd.read_excel(DATA_FILE)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        sys.exit(f"В файле {DATA_FILE} не хватает колонок: {missing}")
    df["Дата рождения"] = pd.to_datetime(df["Дата рождения"])
    return df


def load_sent_log() -> set:
    if not SENT_LOG_FILE.exists():
        return set()
    with open(SENT_LOG_FILE, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return {row["key"] for row in reader}


def append_sent_log(rows):
    is_new = not SENT_LOG_FILE.exists()
    SENT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SENT_LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["key", "ФИО", "Дата отправки", "Возраст"])
        if is_new:
            writer.writeheader()
        writer.writerows(rows)


def find_jubilarians(df: pd.DataFrame, target_date: date):
    result = []
    for _, row in df.iterrows():
        birth = row["Дата рождения"]
        if pd.isna(birth):
            continue
        age = target_date.year - birth.year
        if age < MILESTONE_START or age % MILESTONE_STEP != 0:
            continue
        try:
            bday_this_year = date(target_date.year, birth.month, birth.day)
        except ValueError:
            bday_this_year = date(target_date.year, birth.month, 28)  # 29 февраля
        if bday_this_year == target_date:
            result.append((row, age))
    return result


def send_email(to_email: str, subject: str, body: str):
    if not (SMTP_SERVER and SMTP_USERNAME and SMTP_PASSWORD):
        sys.exit("Не заданы SMTP-параметры (SMTP_SERVER / SMTP_USERNAME / SMTP_PASSWORD).")
    msg = MIMEMultipart()
    msg["From"] = SMTP_USERNAME
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SMTP_USERNAME, to_email, msg.as_string())


def main():
    target_date = date.today() + timedelta(days=REMINDER_DAYS_BEFORE)
    df = load_employees()
    already_sent = load_sent_log()
    jubilarians = find_jubilarians(df, target_date)

    if not jubilarians:
        print(f"На {target_date.isoformat()} юбиляров не найдено.")
        return

    new_log_rows = []
    for row, age in jubilarians:
        full_name = str(row["ФИО"]).strip()
        email = str(row.get("Email", "")).strip()
        key = f"{full_name}|{target_date.year}|{age}"

        if key in already_sent:
            print(f"Пропуск (уже отправлено ранее): {full_name}")
            continue
        if not email or "@" not in email:
            print(f"Пропуск (нет корректного email): {full_name}")
            continue

        body = build_message(full_name, age)
        subject = f"Поздравляем с юбилеем, {age} лет!"
        try:
            send_email(email, subject, body)
            print(f"Отправлено: {full_name} <{email}>")
            new_log_rows.append({
                "key": key,
                "ФИО": full_name,
                "Дата отправки": date.today().isoformat(),
                "Возраст": age,
            })
        except Exception as e:
            print(f"Ошибка отправки для {full_name}: {e}")

    if new_log_rows:
        append_sent_log(new_log_rows)


if __name__ == "__main__":
    main()
